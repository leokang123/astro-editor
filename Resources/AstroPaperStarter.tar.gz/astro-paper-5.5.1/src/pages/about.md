---
layout: ../layouts/AboutLayout.astro
title: "About"
---

Write a short introduction for your blog here.

## Topics

- Notes
- Projects
- Technical writing

