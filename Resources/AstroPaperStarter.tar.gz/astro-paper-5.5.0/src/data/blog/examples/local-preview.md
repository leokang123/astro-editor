---
title: Settings 탭과 로컬 확인
pubDatetime: 2026-05-18T00:00:00.000Z
modDatetime: 2026-05-18T00:00:00.000Z
description: Preferences에서 프로젝트, 홈, 소셜, 이미지, Git, Docker preview를 관리하는 방법입니다.
tags:
  - example
  - settings
featured: false
draft: false
---

AstroPaperEditor의 Preferences는 글 본문 밖의 프로젝트 설정을 다룹니다. 모든 설정을 앱 안에 숨기지 않고, 실제 프로젝트 파일을 보여주고 수정하는 방식입니다.

## Project

Project 탭은 현재 열린 프로젝트의 중요한 경로를 보여줍니다.

- 프로젝트 루트
- 블로그 글 폴더 `src/data/blog`
- About 페이지 `src/pages/about.md`
- AstroPaper 설정 파일 `src/config.ts`
- 앱용 설정 파일 `src/user-settings.json`

`Choose Project Folder`로 다른 프로젝트를 열 수 있습니다. 폴더 선택창에서 새 폴더를 만든 뒤 열면, 빈 폴더인 경우 앱이 AstroPaper v5.5.0 기반 starter project 생성을 제안합니다.

## About

About 탭은 `src/pages/about.md`를 편집합니다. 본문은 Markdown으로 쓰고, 프로필 이미지는 버튼으로 바꿀 수 있습니다.

프로필 이미지를 선택하면 앱이 이미지를 프로젝트의 `public` 아래로 복사하고, about 페이지 frontmatter의 `profileImage` 값을 업데이트합니다. 저장하기 전에는 변경사항이 파일에 반영되지 않습니다.

## Home

Home 탭은 `src/user-settings.json`을 편집합니다. 사이트 제목, 설명, 작성자, 웹사이트 주소, 프로필 주소, 홈 화면 문구, 페이지당 글 수 같은 값을 관리합니다.

`Open Website`는 이 설정의 `website` 값을 엽니다. 로컬 Docker preview를 보고 싶을 때는 보통 `http://localhost:4321/`을 사용합니다.

## Social

Social 탭은 `src/user-settings.json`의 `USER_SOCIALS`를 편집합니다. GitHub, X, LinkedIn, Mail 같은 링크를 켜고 끌 수 있고, 각 서비스의 URL을 입력할 수 있습니다.

메일 링크는 보통 `mailto:name@example.com` 형식을 씁니다.

## Assets

Assets 탭은 `src/assets/images`를 정리할 때 씁니다. Scan은 글, 페이지, 레이아웃, 컴포넌트, 사이트 설정에서 이미지 파일명이 참조되는지 확인합니다.

참조되지 않는 이미지는 Optimize 버튼으로 macOS Trash로 보낼 수 있습니다. 바로 삭제하지 않고 휴지통으로 보내기 때문에 실수했을 때 복구할 여지가 있습니다.

## Git

Git 탭은 현재 프로젝트의 Git 상태를 보여줍니다. 저장소가 초기화되어 있는지, 현재 브랜치가 무엇인지, remote URL이 설정되어 있는지 확인할 수 있습니다.

Remote URL과 branch를 입력하면 앱의 Commit & Push 흐름에서 사용할 저장소 설정을 준비할 수 있습니다.

## Developer

Developer 탭은 로컬 확인용 Docker preview를 실행합니다. 앱은 고정된 Docker Compose project name을 사용합니다.

```bash
docker compose -p astropaper-editor-preview down
docker compose -p astropaper-editor-preview up --build -d
```

이 preview는 디버깅과 확인용입니다. 한 번에 하나의 preview를 `http://localhost:4321/`에서 보는 전제로 동작합니다. 다른 프로젝트에서 다시 실행하면 이전 preview 컨테이너를 내리고 새 프로젝트 기준으로 다시 빌드합니다.

Docker는 프로젝트의 Dockerfile을 사용해 `pnpm run build`를 실행하고, 생성된 `dist` 폴더를 nginx로 서빙합니다. 그래서 Developer preview는 실시간 개발 서버가 아니라, 현재 프로젝트가 실제 Astro build를 통과하는지 확인하는 로컬 미리보기입니다.
