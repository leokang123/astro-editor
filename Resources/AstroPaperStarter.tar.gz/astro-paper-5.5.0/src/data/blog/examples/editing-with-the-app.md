---
title: 글 작성, Frontmatter, Preview
pubDatetime: 2026-05-18T00:00:00.000Z
modDatetime: 2026-05-18T00:00:00.000Z
description: AstroPaperEditor에서 글의 메타데이터와 Markdown 본문을 작성하는 방법입니다.
tags:
  - example
  - writing
featured: false
draft: false
---

AstroPaper 글은 위쪽 frontmatter와 아래쪽 본문으로 나뉩니다. 앱은 새 글을 만들 때 AstroPaper에 맞는 frontmatter를 생성하고, 오른쪽 Inspector에서 자주 쓰는 값을 편집하게 해줍니다.

```md
---
title: 글 제목
pubDatetime: 2026-05-18T00:00:00.000Z
modDatetime: 2026-05-18T00:00:00.000Z
description: 글 목록과 미리보기에 쓰일 짧은 설명
tags:
  - note
featured: true
draft: false
---

여기부터 본문입니다.
```

Inspector에서 다룰 수 있는 값은 `title`, `order`, `description`, `featured`, `pubDatetime`, `modDatetime`, `tags`입니다. 태그는 쉼표로 적어도 되고 줄마다 하나씩 적어도 됩니다. 앱이 모르는 frontmatter 필드는 지우지 않고 `Preserved Extra Fields`에 보존합니다.

`featured: true`인 글은 툴바의 Featured 화면에서 모아볼 수 있습니다. 글을 저장하면 `modDatetime`은 현재 시간으로 갱신됩니다.

OG 이미지는 새 글 만들 때 선택하거나 Inspector의 `OG Image`에서 고를 수 있습니다. 선택한 이미지는 `src/assets/images`로 복사되고, 글의 `ogImage` 값으로 연결됩니다.

본문 편집기는 Markdown을 그대로 씁니다. 이미지를 붙여넣거나 드래그하면 앱이 파일을 저장하고 Markdown 이미지 문법을 삽입합니다.

```md
![2026-05-18-001](@/assets/images/2026-05-18-001.png)
```

`@/assets/images/...` 경로는 프로젝트의 `src/assets/images`를 가리킵니다. 앱의 Preview도 이 경로를 로컬 이미지로 해석해서 보여줍니다.

Preview는 `Command + E`로 열 수 있습니다. 앱의 미리보기는 글쓰기 확인용으로 다음을 지원합니다.

- 제목, 문단, 링크, 굵게, 기울임, 인라인 코드
- 순서 없는 목록과 인용문
- 코드 블록
- Markdown 표
- 로컬 이미지 경로
- Mermaid 코드 블록
- LaTeX 수식

예를 들어 표는 이렇게 확인할 수 있습니다.

| 기능 | 용도 |
| --- | --- |
| Inspector | frontmatter 편집 |
| Preview | 렌더링 확인 |
| Assets | 사용하지 않는 이미지 정리 |

Mermaid는 fenced code block으로 씁니다.

```mermaid
flowchart LR
  Draft --> Preview
  Preview --> Save
```

수식은 인라인과 블록 방식으로 확인할 수 있습니다.

인라인 예시: $a^2 + b^2 = c^2$

문법은 이렇게 씁니다.

```md
$a^2 + b^2 = c^2$
```

$$
E = mc^2
$$

미리보기는 AstroPaper 사이트 전체 렌더러를 완전히 대체하지는 않습니다. 글을 발행하기 전에는 Developer 탭의 로컬 preview로 실제 AstroPaper 화면도 확인하는 것이 좋습니다.
