---
title: AstroPaperEditor 시작하기
pubDatetime: 2026-05-18T00:00:00.000Z
modDatetime: 2026-05-18T00:00:00.000Z
description: 새 AstroPaper 프로젝트를 열고 첫 글을 쓰기 전에 알아두면 좋은 기본 흐름입니다.
tags:
  - example
  - guide
featured: true
draft: false
---

AstroPaperEditor는 범용 메모 앱이 아니라, AstroPaper v5 계열 블로그를 편집하기 위한 로컬 파일 편집기입니다. 글은 데이터베이스에 저장되지 않고 이 프로젝트 안의 Markdown 파일로 그대로 남습니다.

```text
src/data/blog/
  examples/
    welcome.md
```

왼쪽 사이드바는 `src/data/blog` 폴더를 읽어서 만듭니다. 폴더는 카테고리처럼 보이고, `.md` 파일은 글처럼 보입니다. 예를 들어 `src/data/blog/network/tcp.md`를 만들면 앱에서는 `network` 카테고리 안의 `tcp` 글로 다룹니다.

기본 작업 흐름은 단순합니다.

- `Project` 버튼으로 AstroPaper 프로젝트 루트를 엽니다.
- 사이드바에서 카테고리나 글을 선택합니다.
- `Command + N`으로 새 글을 만듭니다.
- 본문은 가운데 편집기에서 쓰고, 제목과 날짜 같은 frontmatter는 오른쪽 Inspector에서 다룹니다.
- `Command + S`로 저장합니다. 자동 저장은 하지 않습니다.
- `Command + E`로 Edit와 Preview를 오갑니다.

앱은 글을 선택했을 때만 파일을 읽고, 저장 버튼을 누를 때만 파일을 씁니다. 그래서 Finder, Terminal, 다른 에디터와 함께 써도 구조가 단순합니다.

처음 만든 프로젝트에는 예시 글이 몇 개 들어 있습니다. 구조를 확인한 뒤 지워도 되고, 이름을 바꿔서 첫 글의 초안으로 써도 됩니다.
